Modules
=======

A great deal of functionality in Annotator is provided by modules. These pages
document these modules and how they work together.

.. toctree::
   :glob:
   :maxdepth: 1

   *
