Annotator Change History
~~~~~~~~~~~~~~~~~~~~~~~~

All notable changes to this project are documented here. This project
endeavours to adhere to `Semantic Versioning`_.

.. _Semantic Versioning: http://semver.org/

.. include:: ../CHANGES.rst
