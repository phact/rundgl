.. default-domain: js

annotator.ui package
====================

.. include:: ui/main.rst
   :start-line: 5

.. include:: ui/markdown.rst
   :start-line: 5

.. include:: ui/tags.rst
   :start-line: 5
