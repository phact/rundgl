API documentation
=================

.. toctree::
   :maxdepth: 2

   app
   registry
   storage
   authz
   identity
   notification
   ui
