// Manually export annotator onto the window object so that ext modules can find it.
window.annotator = require('../browser');
