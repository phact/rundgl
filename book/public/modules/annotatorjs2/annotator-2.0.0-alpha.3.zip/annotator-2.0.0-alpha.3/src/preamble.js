/*
** Annotator {{VERSION}}
** https://github.com/okfn/annotator/
**
** Copyright {{YEAR}}, the Annotator project contributors.
** Dual licensed under the MIT and GPLv3 licenses.
** https://github.com/okfn/annotator/blob/master/LICENSE
**
** Built at: {{DATE}}
*/
